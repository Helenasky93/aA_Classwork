require_relative "PolyTreeNode.rb"

class KnightPathFinder

    def initialize(start_pos)
        self.root_node = PolyTreeNode.new(start_pos) #@root_node = self.root_node
        @considered_positions = Array.new

    end

    def build_move_tree(root_node, target) #node.root_node = [0, 0] 
        position = root_node.value #starting position
        queue = Array.new #initilize queue 
        return root_node if root_node.value == target #return node if correct node
        queue.concat(new_move_positions(position)
        until queue.empty?
            element = queue.shift #popped off first element from queue
            return element if element.value == target
            queue.concat(new_move_positions(element.value)) 
        end
        nil
    end


    def self.valid_moves(start_pos) # 0, 0
        possible_moves = [
            [1, 2], [2, 1],
            [2, -1], [1, -2],
            [-1, -2], [-2, -1],
            [-2, 1], [-1, 2]
        ]
        moves = Array.new
        start_x = start_pos[0] # x = 0
        start_y = start_pos[1] #y = 0
        possible_moves.each do |move| #move = [1, 2]
            x, y = move # x = 1, y = 2
            new_x = x + start_x
            new_y = y + start_y 
            if (new_x >= 0 && new_x <= 7) && (new_y >= 0 && new_y <= 7)
                moves << [new_x, new_y]
            end
        end
        moves
    end

    def new_move_positions(pos)
        moves = KnightPathFinder.valid_moves(pos) #moves is an array of possible moves
        new_moves = moves.select {|move| !@considered_positions.include?(move)}
        @considered_positions.concat(new_moves)
        new_moves
    end
    
end