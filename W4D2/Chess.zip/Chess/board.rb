require_relative "piece.rb"

class Board
  attr_reader :rows, :sentinel

  def initialize
    @rows = Array.new(8) {Array.new(8)}
    @sentinel = nil
    build_board
  end

  def build_board #(color,board,position)
    @rows[0].each_with_index do |row,idx|
      @rows[0][idx] = Piece.new(:w, self,[0,idx] )
    end
    @rows[1].each_with_index do |row,idx|
      @rows[1][idx] = Piece.new(:w, self,[1,idx] )
    end
    @rows[6].each_with_index do |row,idx|
      @rows[6][idx] = Piece.new(:w, self,[6,idx] )
    end
    @rows[7].each_with_index do |row,idx|
      @rows[7][idx] = Piece.new(:w, self,[7,idx] )
    end
    i = 2
    while i < 6
      @rows[i].each_with_index do |row,idx|
        @rows[i][idx] = @sentinel
      end
      i += 1
    end

    

  end
  def [](pos)
    @rows[pos[0]][pos[1]]
  end

  def move_piece(start_pos, end_pos)
    raise "empty space" if [start_pos] == nil
    raise "space taken" if [end_pos] != nil
    [end_pos] = [start_pos]
    [start_pos] = @sentinel
  end

end