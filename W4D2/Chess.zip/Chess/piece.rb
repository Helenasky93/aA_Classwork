class Piece
  def initialize(color,board,position)
    @board = board
    @position = position
    @color = color
  end

end