require_relative "piece.rb"
require_relative "king.rb"
require_relative "knight.rb"
require 'byebug'
class Board
  attr_reader :rows, :sentinel

  def initialize
    @rows = Array.new(8) {Array.new(8)}
    @sentinel = nil
    build_board
  end

  def build_board #(color,board,position)// king idx = 3// knight idx 1,6
    
    @rows[0].each_with_index do |row,idx|
      if idx == 3
        @rows[0][idx] = King.new(:W, self, [0,idx]) 
      elsif idx == 1 || idx == 6
        @rows[0][idx] = Knight.new(:W, self, [0,idx])
      else
        @rows[0][idx] = Piece.new(:W, self,[0,idx]) 
      end
    end
    
    @rows[1].each_with_index do |row,idx|
      @rows[1][idx] = Piece.new(:W, self,[1,idx] )
    end
    @rows[6].each_with_index do |row,idx|
      @rows[6][idx] = Piece.new(:B, self,[6,idx] )
    end
    
    @rows[7].each_with_index do |row,idx|
      if idx == 3
        @rows[7][idx] = King.new(:B, self, [7,idx]) 
      elsif idx == 1 || idx == 6
        @rows[7][idx] = Knight.new(:B, self, [7,idx])
      else
        @rows[7][idx] = Piece.new(:B, self,[7,idx]) 
      end
    end
    
    i = 2
    while i < 6
      @rows[i].each_with_index do |row,idx|
        @rows[i][idx] = @sentinel
      end
      i += 1
    end

    

  end
  def [](pos)
    @rows[pos[0]][pos[1]]
  end
  def []=(pos,value)
    @rows[pos[0]][pos[1]] = value
  end

  def move_piece(start_pos, end_pos) #args are coordinates
    
    start_pos.each do |ele|
      if ele > 7 || ele < 0
        raise "no such coordinate"
      end
    end
    end_pos.each do |ele|
      if ele > 7 || ele < 0
        raise "no such coordinate"
      end
    end
    raise "empty space" if [start_pos] == nil

    
    self[end_pos] = self[start_pos]
    self[start_pos] = @sentinel
    # p self
    # self.[]=(end_pos, 3)
  end

end