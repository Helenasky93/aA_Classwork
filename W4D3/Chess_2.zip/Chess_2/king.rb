
require_relative 'steppable.rb'
require 'byebug'

class King < Piece
  include Steppable
  attr_reader :symbol
  K_MOVES = [[1,1],[-1,0],[1,0],[1,-1],[0,-1],[-1,-1],[-1,1],[0,1]]
  def initialize(color, board, position)
    super
    @symbol = :K
  end
   
  def move_diffs
    # debugger
    pos_moves = []
    
    x = self.position[0]
    y = self.position[1] #[0,0]
    K_MOVES.each do |move|
      pos_moves << [x + move[0], y + move[1]] #check if pos moves are valid??
    end
    valid_moves = moves(pos_moves)
    valid_moves
  end

end