require "byebug"
require_relative 'steppable.rb'
class Knight < Piece
  include Steppable
  KN_MOVES = [[-1,-2],[1,-2],[2,-1],[2,1],[1,2],[-1,2],[-2,1],[-2,-1]]
  def initialize(color, board, position)
    super
    @symbol = :KN
  end
   
  def move_diffs
    pos_moves = []
    # ve_diffs
    x = self.position[0]
    y = self.position[1] #[0,0]
    KN_MOVES.each do |move|
      pos_moves << [x + move[0], y + move[1]] #check if pos moves are valid??
    end
    valid_moves = moves(pos_moves)
    valid_moves
  end
end