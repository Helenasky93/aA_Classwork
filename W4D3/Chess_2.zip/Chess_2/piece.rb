class Piece
  attr_accessor :position
  attr_reader :board, :color
  def initialize(color,board,position)
    @board = board
    @position = position
    @color = color
  end

  def moves
    pos_moves = []
  end
end