class Rook < Piece
  def initialize(color,board,position)
    super
    @symbol = :R
  end

  def move_dirs
    horizontal = []
    vertical = []
    x = self.pos[0] #7
    y = self.pos[1] #0
    (0..7).each do |i| # vertical
      if i != x
        vertical << [i,y]
      end
    end
    (0..7).each do |j| # horizontal
      if j != y
        vertical << [x,j]
      end
    end
  end
end