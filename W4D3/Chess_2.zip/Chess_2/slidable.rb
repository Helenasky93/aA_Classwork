

module Slidable
  def move_dirs  
    raise NoMethodError
  end
  def horizontal_dirs(vertical,horizontal)
    res = []
    subs_v = []
    subs_h = []
    #iterate thru each vertical pos. save that range to a var. until it hits obsticle
    vertical.each do |pos|
      self
    end
  end
end