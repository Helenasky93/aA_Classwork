require 'byebug'
module Steppable
  
  # knight/king
  # king = +1/-1 in every direction (horizontal/vertical/diagonal)
  # knight = +2/-2 horizontal/vertical then +1/-1 perpendicular
  def move_diffs  
    raise NoMethodError
  end
  #cant move into a pos of a piece with same color
  #can hop over pieces.
  def moves(pos_moves) #maybe dont take arg and use move_diffs inside.
    # debugger
    res = []
    pos_moves.each do |pos|
      pos_at_board = @board.rows[pos[0]][pos[1]]
      if within_bounds?(pos)
        if @board.rows[pos[0]][pos[1]] == nil
          res << pos
          
        elsif pos_at_board.color != self.color
          res << pos
        end
      end
    end
    res
  end
  def within_bounds?(pos)
    pos.each do |n|
      if n < 0 || n > 7
        return false
      end
    end
    true
  end
end