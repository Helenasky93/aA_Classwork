require "byebug"

# my_min
# Given a list of integers find the smallest number in the list.

# Example:

#     list = [ 0, 3, 5, 4, -5, 10, 1, 90 ]
#     my_min(list)  # =>  -5
# Phase I
# First, write a function that compares each element to every other element of the list. Return the element if all other elements in the array are larger.
# What is the time complexity for this function?

def my_min(list) #n^2
  list.each_with_index do |el, idx|
    if list.all? { |el2| list[idx] <= el2 }
      return list[idx]
    end
  end
end


# Phase II
# Now rewrite the function to iterate through the list just once while keeping track of the minimum. What is the time complexity?

def my_min_phaseII(list) #O(n) linear
  list.inject {| accum, el| el < accum ? accum = el : accum }
end

# Largest Contiguous Sub-sum
# You have an array of integers and you want to find the largest contiguous (together in sequence) sub-sum. Find the sums of all contiguous sub-arrays and 
#return the max.

# Example:

#     list = [5, 3, -7]
#     largest_contiguous_subsum(list) # => 8

#     # possible sub-sums
#     [5]           # => 5
#     [5, 3]        # => 8 --> we want this one
#     [5, 3, -7]    # => 1
#     [3]           # => 3
#     [3, -7]       # => -4
#     [-7]          # => -7
# Example 2:

#     list = [2, 3, -6, 7, -6, 7]
#     largest_contiguous_subsum(list) # => 8 (from [7, -6, 7])
# Example 3:

#     list = [-5, -1, -3]
#     largest_contiguous_subsum(list) # => -1 (from [-1])
# Phase I
# Write a function that iterates through the array and finds all sub-arrays using nested loops. First make an array to hold all sub-arrays. Then find the
# sums of each sub-array and return the max.

# Discuss the time complexity of this solution.

def largest_contiguous_subsum(arr) #n^3
  sub_sums =[]
  arr.each_with_index do |el, idx1|
    arr.each_with_index do |el2, idx2|
      if idx2 >= idx1
      sub_sums << arr[idx1..idx2]
      end
    end
  end
  sub_sums.map {|sub| sub.sum}.max
end

# Phase II
# Let's make a better version. Write a new function using O(n) time with O(1) memory. 
#Keep a running tally of the largest sum. To accomplish this efficient space complexity, 
#consider using two variables. One variable should track the largest sum so far and another to track the current sum. We'll leave the rest to you.
def largest_contiguous_subsum_2(arr) #[5, 3, -7]
  # debugger
  largest_sum_so_far = 0
  running_total = 0
  negative_sum = arr.first
  (0...arr.length).each do |i|
    if arr[i] + running_total < 0
      running_total = 0
    else
      running_total += arr[i]
      largest_sum_so_far = running_total if running_total > largest_sum_so_far
    end
    if arr[i] > negative_sum
      negative_sum = arr[i]
    end
  end
  if largest_sum_so_far <= 0 
    return negative_sum
  else
    return largest_sum_so_far
  end
end

# [4, -2, 4]
# Get your story straight, and then explain your solution's time complexity to your TA.



