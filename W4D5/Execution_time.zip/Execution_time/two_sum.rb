def two_sum?(arr, target_sum)
  arr.each_with_index do |num, i|
    arr.each_with_index do |num2, i2|
      return true if arr[i] + arr[i2] == target_sum && i2 > i 
    end
  end
  false
end




