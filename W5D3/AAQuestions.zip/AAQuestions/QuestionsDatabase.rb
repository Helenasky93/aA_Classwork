require 'sqlite3'
require 'singleton'


class QuestionsDatabase < SQLite3::Database
  include Singleton
  def initialize
    super('questions.db')
    self.type_translation = true
    self.results_as_hash = true
  end

end

class User < QuestionsDatabase
  attr_accessor :id, :fname, :lname

  def self.find_by_id
    user = User.new
  end
  def initialize(options)
    @id = options['id']
    @fname = options['fname']
    @lname = options['lname']

  end

end

class QuestionFollow < QuestionsDatabase
  attr_accessor :id, :question_id, :user_id
  def self.find_by_id
    question_follow = QuestionFollow.new
  end
  def initialize(options)
    @id = options['id']
    @question_id = options['question_id']
    @user_id = options['user_id']
    
  end

end

class QuestionReply < QuestionsDatabase
  attr_accessor :id, :subject_question_id, :parent_reply_id, :body
  def self.find_by_id
    question_reply = QuestionReply.new
  end
  def initialize(options)
    @id = options['id']
    @subject_question_id = options['subject_question_id']
    @parent_reply_id = options['parent_reply_id']
    @body = options['body']
  end

end

class QuestionLike < QuestionsDatabase
  attr_accessor :id, :user_id, :question_id
  def self.find_by_id
    question_like = QuestionLike.new
  end
  def initialize(options)
    @id = options['id']
    @user_id = options['user_id']
    @question_id = options['question_id']
  end

end