// // function sum() {
// //     let sum = 0;
// //     Object.values(arguments).forEach(arg => sum+= arg);
// //     return sum;
// // }

// // console.log(sum(1, 3, 5));

// Function.prototype.myBind = function(context, ...btargs) {
//     const that = this
//     return function (...ctargs) {
//         that.apply(context, btargs.concat(ctargs));
//     }
    
// }

// class Cat {
//     constructor(name) {
//         this.name = name;
//     }

//     says(sound, person) {
//         console.log(`${this.name} says ${sound} to ${person}!`);
//         return true;
//     }
// }

// class Dog {
//     constructor(name) {
//         this.name = name;
//     }
// }

// // const markov = new Cat("Markov");
// // const pavlov = new Dog("Pavlov");

// // markov.says("meow", "Ned");
// // // Markov says meow to Ned!
// // // true

// // // bind time args are "meow" and "Kush", no call time args
// // markov.says.myBind(pavlov, "meow", "Kush")();
// // // Pavlov says meow to Kush!
// // // true

// // // no bind time args (other than context), call time args are "meow" and "a tree"
// // markov.says.myBind(pavlov)("meow", "a tree");
// // // Pavlov says meow to a tree!
// // // true

// // // bind time arg is "meow", call time arg is "Markov"
// // markov.says.myBind(pavlov, "meow")("Markov");
// // // Pavlov says meow to Markov!
// // // true

// // // no bind time args (other than context), call time args are "meow" and "me"
// // const notMarkovSays = markov.says.myBind(pavlov);
// // notMarkovSays("meow", "me");
// // // Pavlov says meow to me!
// // // true

// function curriedSum(numArgs) {
//     let nums = [];
//     return function _curriedSum(num) {
//         nums.push(num);

//         if (nums.length === numArgs) {
            
//             return nums.reduce((acc, currNum) => acc + currNum );
            
//         } 
//         return _curriedSum
//     }
//     // return _curriedSum

// }

// curriedSum(1)
// curriedSum(2)
// const sum = curriedSum(4);
// console.log(sum);
// console.log(sum(5)(30)(20)(1)); // => 56
function sumThree(num1, num2, num3) {
    return num1 + num2 + num3;
}

Function.prototype.curry = function(numArgs) {
    let nums = [];
    const that = this;
    return function _curriedSum(num) {
        nums.push(num);

        if (nums.length === numArgs) {

            return that(...nums);

        }
        return _curriedSum
    } 
}

console.log(sumThree.curry(3)(4)(20)(6));